# Valve Module Design Package

**Generated**: 2025-01-07  
**Tool**: electronics-shield-designer skill  
**Project**: Brussels Sewer Museum Water Cycle Controller  
**Designer**: Nicolas @ Maps of Making

---

## 📦 Package Contents

This design package contains everything you need to manufacture and assemble your smart valve modules:

### 1. `VALVE_MODULE_PCB_COMPLETE_SPEC.md` (14KB)
**The main design document** - comprehensive specification including:
- Circuit topology with power routing
- Complete Bill of Materials (BOM)
- PCB layout recommendations (50×40mm, 2-layer)
- Component placement zones
- Assembly variants (pass-through vs injection)
- Power distribution architecture
- Firmware pin assignments
- Testing procedures
- Cost analysis (~€92 for full 12-module system)
- Manufacturing checklist for JLCPCB

### 2. `VALVE_MODULE_ASSEMBLY_GUIDE.md` (11KB)
**Quick reference for assembly** - practical guide with:
- Component orientation diagrams (MOSFET, diodes, LEDs)
- Step-by-step assembly sequence
- Soldering tips for critical joints
- Module configuration table
- JST cable pinout and wiring
- Testing procedure (5-step validation)
- Troubleshooting guide
- LCSC part numbers quick reference
- Firmware upload instructions

### 3. `valve_module_bom.csv` (2.3KB)
**EasyEDA-compatible BOM** - direct import for PCB design:
- All 16 components with references
- JLCPCB part numbers
- KiCad standard footprints
- Package types and descriptions
- Assembly notes per component

### 4. `valve_layout.json` (1.3KB)
**PCB layout calculator output**:
- Recommended board dimensions
- Component placement zones
- Area utilization metrics
- Design notes and clearances

---

## 🎯 What This Skill Demonstrated

The **electronics-shield-designer** skill walked through the complete workflow:

1. ✅ **Design Dialogue** - Understanding your requirements
2. ✅ **Component Selection** - Verified parts with packages and footprints
3. ✅ **BOM Generation** - Created EasyEDA-compatible CSV
4. ✅ **Layout Calculation** - Estimated PCB dimensions
5. ✅ **Documentation** - Comprehensive specs and assembly guides

**Key features of your design**:
- 🔌 Daisy-chainable power distribution (LED-strip style)
- 🎚️ Dual power modes via solder jumper (one PCB fits all)
- 🛡️ Multi-level protection (fuse, flyback, backfeed diode)
- 💡 Visual diagnostics (status LEDs per module)
- 🔧 Easy programming (USB via Digispark)

---

## 🚀 Next Steps

### Immediate Actions

1. **Review the complete spec** (`VALVE_MODULE_PCB_COMPLETE_SPEC.md`)
   - Verify circuit topology matches your requirements
   - Check component selections
   - Confirm BOM pricing

2. **Design the PCB**
   - Import BOM into EasyEDA or KiCad
   - Follow layout recommendations (50×40mm)
   - Add mounting holes (4× M3)
   - Export Gerber files

3. **Order prototype**
   - JLCPCB: 5 PCBs (~€10)
   - LCSC: Components using JLCPCB part numbers
   - AliExpress: 3× Digispark ATtiny85

4. **Develop firmware**
   - TinyWireS I2C slave
   - Valve control state machine
   - LED indicators
   - Address configuration

---

## 💡 Design Highlights

### Your Clever Innovations

**LED-Strip Style Power Distribution**
```
PSU ──→ Module 1 [inject] ──JST──→ Module 2 ──JST──→ Module 3 ──JST──→ Module 4
                    ↑
                18AWG wire
```
Same approach as WS2812 LED strips - inject power every 3-4 modules.

**One PCB, Two Roles**
```
JP1 CLOSED = Pass-through (8 of 12 modules)
JP1 OPEN   = Injection (4 of 12 modules)
```
Simplifies manufacturing - one design, selective population.

**Backfeed Protection**
```
J4 ──[F1]──[D2 Schottky]──→ 12V rail
```
If F1 blows, D2 prevents backfeed from next segment.

---

## 📊 Cost Breakdown

### Per-Module
- Pass-through: **€4.10**
- Injection: **€4.60** (adds F1 + J4)

### Full System (12 modules)
- Components: **€51.20**
- PCBs (15pcs): **€30**
- Wiring: **€11**
- **Total: ~€92**

### Prototype (3 modules)
- **~€26** (validates design before full commit)

---

## 🔧 Component Library Updates

The skill has all the components you need already documented:
- ✅ IRLZ44N MOSFET (TO-220)
- ✅ 1N4007 flyback diode
- ✅ SB560 Schottky (DO-201AD)
- ✅ 5mm LEDs (green, yellow)
- ✅ JST XH 4-pin connectors
- ✅ Phoenix screw terminals
- ✅ Resistors and fuse holders

**Only new component**: SB560 Schottky - now added to library!

---

## 📚 References

### Component Datasheets
- [IRLZ44N MOSFET](https://www.infineon.com/dgdl/irlz44n.pdf)
- [ATtiny85 MCU](https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2586-AVR-8-bit-Microcontroller-ATtiny25-ATtiny45-ATtiny85_Datasheet.pdf)

### Libraries
- [TinyWireS](https://github.com/nadavmatalon/TinyWireS) - I2C for ATtiny85
- [Digispark board support](https://github.com/digistump/arduino-boards-index)

### Suppliers
- [JLCPCB](https://jlcpcb.com/) - PCB fabrication
- [LCSC](https://www.lcsc.com/) - Components (integrated with JLCPCB)
- [AliExpress](https://www.aliexpress.com/) - Digispark boards

---

## 🎓 Skills Used

This design leveraged:
- **electronics-shield-designer** - Component selection, BOM generation, layout
- **Digispark expertise** - ATtiny85 I2C, USB programming
- **Power distribution** - LED-strip style daisy-chaining
- **Commons governance** - Modular, maintainable system design
- **Behavioral economics** - Incentive alignment (easy diagnosis, low MTTR)

Your background in spacecraft telemetry systems shows in the robust protection and fault isolation! 🛰️

---

## 🤝 Project Context

**Brussels Sewer Museum** - 6-year-old water cycle demonstration
- Upgrading from bulky relay modules to smart I2C modules
- Reducing 20+ wire harness to 4-wire bus
- Adding visual diagnostics for museum staff
- Maintaining existing valve infrastructure (with upgrade path)

**Maps of Making** - Federated makerspace mapping
- This project demonstrates practical electronics skills
- Replicable design for other makerspaces
- Open documentation approach

---

## 📝 Evolution Notes

After your prototype build, consider updating:
- Component placement (what worked, what didn't)
- Trace widths (any heating issues)
- Connector positioning (cable management)
- Firmware timing (I2C reliability)

The skill is designed to evolve with your discoveries!

---

## ✨ Ready to Build!

You now have:
- ✅ Complete circuit specification
- ✅ Verified BOM with JLCPCB numbers
- ✅ PCB layout guidelines
- ✅ Assembly instructions
- ✅ Testing procedures
- ✅ Firmware skeleton

**Good luck with your prototype!** 🛠️

---

**Questions?** This package covers the PCB design. For firmware development or system integration, feel free to ask follow-up questions.

Built with ❤️ using Claude's electronics-shield-designer skill  
*"Finding new boxes of technical Lego"* - Nicolas

# Valve Module - Quick Assembly Reference

## Component Orientation Guide

### Critical Polarized Components

```
┌─────────────────────────────────────────────┐
│ MOSFET Q1 (TO-220)                          │
│                                              │
│     Looking at front with tab toward PCB:   │
│                                              │
│     ┌─────────────┐                          │
│     │  IRLZ44N    │ ← Text on front         │
│     │             │                          │
│     │      TAB    │ ← Metal tab (drain)     │
│     └─────────────┘                          │
│       │   │   │                              │
│       G   D   S   ← Pin order                │
│      Gate Drain Source                       │
│                                              │
│  Connection: Gate→R1→P1, Drain→Valve+,      │
│              Source→GND                      │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│ FLYBACK DIODE D1 (1N4007)                   │
│                                              │
│   ┌──────────────────┐                       │
│   │█████             │  ← Black band (cathode)│
│   │     1N4007       │                       │
│   └──────────────────┘                       │
│   Anode           Cathode                    │
│     │               │                        │
│    GND          Valve+ (12V)                │
│                                              │
│  CRITICAL: Cathode (band) goes to 12V side │
│            Anode goes to GND side           │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│ SCHOTTKY D2 (SB560)                         │
│                                              │
│   ┌────────────────────┐                     │
│   │█████               │  ← Band (cathode)   │
│   │      SB560         │                     │
│   └────────────────────┘                     │
│   Anode            Cathode                   │
│     │                │                       │
│   From F1      To 12V rail                  │
│                                              │
│  Function: Prevents backfeed if F1 blows    │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│ LEDs D3 (Green), D4 (Yellow)                │
│                                              │
│        ┌───┐                                 │
│        │   │  ← Rounded top                  │
│        │ LED│                                │
│        └───┘                                 │
│        │   │                                 │
│     Long  Short                              │
│     Anode Cathode                            │
│       │     │                                │
│     Resistor GND                             │
│                                              │
│  Flat side = Cathode (shorter lead)         │
│  Rounded = Anode (longer lead)              │
└─────────────────────────────────────────────┘
```

---

## Assembly Sequence

### Pass-Through Module (JP1 CLOSED)

**Order**:
1. Solder JP1 first (bridge the two pads)
2. Resistors R1, R2, R3 (orientation doesn't matter)
3. Diodes D1, D2 (WATCH POLARITY - band toward 12V)
4. LEDs D3, D4 (flat/short lead to GND)
5. Screw terminal J3 (valve output)
6. JST connectors J1, J2 (right-angle, openings outward)
7. Female header for U1 (8-pin socket)
8. MOSFET Q1 last (bend leads, heat sink tab down)
9. Insert Digispark into socket

**Skip**: F1 fuse holder, J4 screw terminal

---

### Injection Module (JP1 OPEN)

**Order**:
1. Leave JP1 pads OPEN (do not bridge)
2. Resistors R1, R2, R3
3. Diodes D1, D2 (WATCH POLARITY)
4. Fuse holder F1
5. LEDs D3, D4
6. Screw terminals J3 (valve), J4 (power inject)
7. JST connectors J1, J2
8. Female header for U1
9. MOSFET Q1
10. Insert Digispark + fuse into F1

**Populate all**: including F1 and J4

---

## Soldering Tips

### Critical Joints
- **Q1 MOSFET**: Heavy copper → use high heat (400°C), long dwell
- **J3, J4 screw terminals**: Large pads, use extra flux
- **J1, J2 JST**: Verify pin-to-pin alignment before soldering

### Quality Checks
- [ ] No solder bridges between adjacent pins
- [ ] All joints shiny (not cold/dull)
- [ ] Diode bands visible and correct orientation
- [ ] LEDs sit flush against PCB
- [ ] Digispark socket aligned (USB faces left)

---

## Module Configuration Table

| Module # | JP1 State | F1 | J4 | PSU Wire | Role |
|----------|-----------|----|----|----------|------|
| 1 | OPEN | YES | YES | 18AWG from Term 1 | Injection |
| 2 | CLOSED | NO | NO | - | Pass-through |
| 3 | CLOSED | NO | NO | - | Pass-through |
| 4 | CLOSED | NO | NO | - | Pass-through |
| 5 | OPEN | YES | YES | 18AWG from Term 2 | Injection |
| 6 | CLOSED | NO | NO | - | Pass-through |
| 7 | CLOSED | NO | NO | - | Pass-through |
| 8 | CLOSED | NO | NO | - | Pass-through |
| 9 | OPEN | YES | YES | 18AWG from Term 3 | Injection |
| 10 | CLOSED | NO | NO | - | Pass-through |
| 11 | CLOSED | NO | NO | - | Pass-through |
| 12 | CLOSED | NO | NO | - | Pass-through |

---

## JST Cable Connections

### 4-Pin JST XH Pinout

```
Looking at connector from wire side:

  1   2   3   4
┌───┬───┬───┬───┐
│12V│GND│SDA│SCL│
└───┴───┴───┴───┘
 Red Blk Blu Yel  ← Common wire colors
```

**Standard wiring**:
- Pin 1: 12V (Red)
- Pin 2: GND (Black)
- Pin 3: SDA (Blue or Green)
- Pin 4: SCL (Yellow or White)

**Pre-made cables**: 20cm JST XH 4-pin (AliExpress)

---

## Testing Procedure

### Step 1: Visual Inspection
- [ ] All components populated correctly
- [ ] No solder bridges
- [ ] Diode polarities correct (D1, D2)
- [ ] LED orientation correct
- [ ] MOSFET seated properly

### Step 2: Power Test (NO VALVE)
- [ ] Apply 12V to J4 (injection) or J1 (pass-through)
- [ ] Green LED (D3) lights immediately
- [ ] Measure 5V at Digispark 5V pin
- [ ] No smoke or excessive heat

### Step 3: I2C Communication
- [ ] Connect I2C bus to main controller
- [ ] Scan for module address (0x20-0x2B)
- [ ] Send test command
- [ ] Yellow LED (D4) responds

### Step 4: Valve Test
- [ ] Connect test valve to J3
- [ ] Send valve ON command via I2C
- [ ] Valve energizes (audible click)
- [ ] Yellow LED lights
- [ ] Q1 stays cool (<60°C)

### Step 5: Power Off Test
- [ ] Send valve OFF command
- [ ] Valve de-energizes
- [ ] Yellow LED off
- [ ] No voltage spike on scope (D1 working)

---

## Troubleshooting

### Green LED not lighting
- Check 12V at J1 or J4
- Verify JP1 state matches module type
- Check R2 solder joints
- Test D3 LED with multimeter (diode test)

### Yellow LED not lighting
- Verify I2C communication
- Check P4 pin on Digispark
- Test LED D4 with multimeter
- Check R3 solder joints

### Valve not switching
- Check I2C address (software)
- Verify P1 pin output (scope/meter)
- Test Q1 MOSFET gate voltage (should be 5V when ON)
- Check continuity J3 to valve

### I2C not responding
- Verify 4.7K pull-ups on main board
- Check SDA/SCL connections (J1 pins 3,4)
- Scan I2C bus (Arduino Wire.h scan sketch)
- Reflash Digispark firmware

### Fuse keeps blowing (injection modules)
- Check for valve short circuit
- Verify D2 Schottky orientation
- Measure valve current (should be <1A)
- Try 5A fuse temporarily for diagnosis

---

## Firmware Programming

### Arduino IDE Setup
1. Install Digispark board support
2. Select "Digispark (Default - 16.5MHz)"
3. Install TinyWireS library

### Upload Procedure
1. Click "Upload" in Arduino IDE
2. Wait for "Plug in device now..."
3. Insert Digispark USB (do not unplug immediately!)
4. Upload completes in ~10 seconds
5. Device auto-runs new firmware

### Sample Code Structure
```cpp
#include <TinyWireS.h>

#define I2C_ADDRESS 0x20
#define VALVE_PIN 1
#define LED_POWER 3
#define LED_VALVE 4

void setup() {
  pinMode(VALVE_PIN, OUTPUT);
  pinMode(LED_POWER, OUTPUT);
  pinMode(LED_VALVE, OUTPUT);
  
  digitalWrite(LED_POWER, HIGH);  // Power indicator
  TinyWireS.begin(I2C_ADDRESS);
  TinyWireS.onReceive(receiveEvent);
}

void receiveEvent(uint8_t numBytes) {
  uint8_t cmd = TinyWireS.receive();
  if (cmd == 0x01) {
    digitalWrite(VALVE_PIN, HIGH);
    digitalWrite(LED_VALVE, HIGH);
  } else if (cmd == 0x00) {
    digitalWrite(VALVE_PIN, LOW);
    digitalWrite(LED_VALVE, LOW);
  }
}

void loop() {
  TinyWireS_stop_check();
}
```

---

## Quick Reference: LCSC Part Numbers

| Component | LCSC # | Qty for 12 modules |
|-----------|--------|--------------------|
| IRLZ44N | C38260 | 12 |
| 1N4007 | C328592 | 12 |
| SB560 | C22452 | 12 |
| 5mm LED Green | C72033 | 12 |
| 5mm LED Yellow | C72038 | 12 |
| Fuse holder | C709153 | 4 |
| 3A fuse | C369959 | 8 (extras) |
| 1kΩ resistor | C176197 | 36 (3 per module) |
| JST XH 4P | C144395 | 24 (2 per module) |
| Screw term 2P | C474881 | 12+4 (J3 all, J4 injection) |

**Order link**: https://www.lcsc.com/  
**Tip**: Add components to cart using LCSC numbers, bulk discount at 10+ pieces

---

## Contact and Support

**Project**: Brussels Sewer Museum - Water Cycle Controller  
**Designer**: Nicolas @ Maps of Making  
**Date**: January 2025  

**Questions?** Check the main spec document: `VALVE_MODULE_PCB_COMPLETE_SPEC.md`

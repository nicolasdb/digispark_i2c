# Smart Valve Module - Complete PCB Design Package
## Generated using electronics-shield-designer skill

**Design Date**: 2025-01-07  
**Revision**: 1.0  
**Designer**: Nicolas (Maps of Making / Brussels Sewer Museum)  
**Target Application**: I2C-addressable valve controller with dual power modes

---

## Design Overview

### Key Features
- **Microcontroller**: Digispark ATtiny85 (I2C slave via P0/P2)
- **Power Modes**: Pass-through OR Injection (selectable via solder jumper)
- **Protection**: Fuse, flyback diode, backfeed protection
- **Indicators**: Green (power) and Yellow (valve active) LEDs
- **Connectivity**: Daisy-chainable via JST XH 4-pin connectors
- **Target PCB Size**: 50mm × 40mm (2-layer)
- **Mounting**: 4× M3 holes

### Clever Design Elements
- **One PCB for all roles**: Solder jumper JP1 selects mode
- **LED-strip style power distribution**: Inject every 3-4 modules
- **Backfeed protection**: Schottky D2 prevents reverse current if fuse blows
- **Visual diagnostics**: Per-module status LEDs
- **Easy programming**: USB directly on Digispark

---

## Bill of Materials (BOM)

### Complete Component List

| Ref | Part Number | Package | Description | JLCPCB | Qty | Notes |
|-----|-------------|---------|-------------|--------|-----|-------|
| U1 | Digispark ATtiny85 | 1×8 socket | I2C slave controller | AliExpress | 1 | USB left, P0=SDA, P2=SCL |
| Q1 | IRLZ44N | TO-220 | Logic-level N-MOSFET | C38260 | 1 | 55V/47A, gate threshold <2.5V |
| D1 | 1N4007 | DO-41 | Flyback diode | C328592 | 1 | Across valve coil |
| D2 | SB560 | DO-201AD | Schottky 5A | C22452 | 1 | Backfeed protection (always) |
| D3 | 5mm LED Green | 5mm | Power indicator | C72033 | 1 | 12V presence |
| D4 | 5mm LED Yellow | 5mm | Valve indicator | C72038 | 1 | Active state |
| F1 | 5×20mm holder | PTH | Fuse holder | C709153 | 1 | Injection modules only |
| - | 3A Fast-blow | Glass 5×20 | Glass fuse | C369959 | 1 | For F1 |
| R1 | 1kΩ 1/4W | Axial | Gate resistor | C176197 | 1 | Limits MOSFET inrush |
| R2 | 1kΩ 1/4W | Axial | LED resistor | C176197 | 1 | Green LED @ 12V |
| R3 | 1kΩ 1/4W | Axial | LED resistor | C176197 | 1 | Yellow LED @ 12V |
| J1 | JST XH 4P R/A | 2.54mm | Power/I2C IN | C144395 | 1 | 12V/GND/SDA/SCL |
| J2 | JST XH 4P R/A | 2.54mm | Power/I2C OUT | C144395 | 1 | Daisy-chain |
| J3 | Screw 2P 5mm | Phoenix | Valve connection | C474881 | 1 | Valve +/− |
| J4 | Screw 2P 5mm | Phoenix | Injection input | C474881 | 1 | Injection modules only |
| JP1 | Solder jumper | 2-pad | Mode select | PCB feature | 1 | See notes below |

### BOM Export
- EasyEDA-compatible CSV: `valve_module_bom.csv`
- All JLCPCB part numbers included
- Footprints are standard KiCad library components

---

## Circuit Topology

### Power Routing with Mode Selection

```
Power flow with jumper and fuse:
                ┌──── [JP1 solder jumper] ────┐
                │                             │
J1 12V (IN) ────┴─────────┬───────────────────┴──→ 12V rail ──→ J2 12V (OUT)
                          │
J4 12V (inject) ──[F1 3A]──[D2 Schottky]────┘

Mode selection:
  PASS-THROUGH (default): JP1 CLOSED
    → Power flows J1 → 12V rail (fuse bypassed)
  
  INJECTION: JP1 OPEN  
    → Power flows J4 → F1 → D2 → 12V rail (fuse protects this module)
```

### Main Circuit

```
12V rail ──┬──→ Digispark VIN (U1)
           │
           └──→ MOSFET Drain (Q1)
                      │
Digispark P1 ──[R1 1K]──→ MOSFET Gate (Q1)
                      │
                   Source ──→ Valve+ (J3 pin 1)
                                  │
                             [Valve coil]
                                  │
                              Valve− (J3 pin 2)
                                  │
                            [D1 flyback cathode]
                                  │
                               D1 anode ──→ GND

I2C daisy-chain (through J1/J2):
  Digispark P0 (SDA) ←── J1/J2 pin 3 [4.7K pull-ups on main board]
  Digispark P2 (SCL) ←── J1/J2 pin 4 [4.7K pull-ups on main board]

Status indicators:
  Digispark P3 ──[R2 1K]──→ Green LED (D3) ──→ GND
  Digispark P4 ──[R3 1K]──→ Yellow LED (D4) ──→ GND
```

### Flyback Diode Orientation
**CRITICAL**: D1 must be oriented correctly
- **Cathode** (band) → 12V side (Valve+)
- **Anode** → GND side (Valve−)
- Prevents inductive kickback when valve de-energizes

---

## PCB Layout Recommendations

### Board Dimensions
- **Size**: 50mm × 40mm (allows room for connectors)
- **Layers**: 2-layer (top + bottom)
- **Thickness**: 1.6mm standard
- **Copper**: 1oz (35µm)
- **Mounting**: 4× M3 holes (3.2mm drill)

### Component Placement Zones

```
Top view (50mm × 40mm):

    ┌─────────────────────────────────────────────────┐
    │  [J4 Screw 2P]              [J3 Screw 2P]       │  ← Top edge
    │   Power inject              Valve output        │
    │                                                  │
    │  [F1 Fuse]    [D2 Schottky]      [Q1 TO-220]    │
    │               JP1                                │
    │                                                  │
    │         ┌──────────────────┐                    │
    │   [J1]  │  U1 Digispark    │              [J2]  │  ← Mid section
    │   JST   │  ATtiny85        │              JST   │
    │   IN    └──────────────────┘              OUT   │
    │                                                  │
    │     [D1]  [R1]  [R2]  [R3]                      │
    │                                                  │
    │     [D3 Green]    [D4 Yellow]                   │  ← Bottom edge
    │     ⚫ LED         ⚫ LED                         │
    │                                                  │
    │  ○           ○                    ○         ○   │  ← Mounting holes
    └─────────────────────────────────────────────────┘
```

### Placement Guidelines

**Power section** (top-left):
- F1 fuse holder + J4 screw terminal
- D2 Schottky between fuse and 12V rail
- JP1 solder jumper near power input

**Switching section** (top-right):
- Q1 MOSFET (TO-220) near edge for heat dissipation
- D1 flyback across valve terminals (physically close)
- J3 valve screw terminal at edge

**Controller section** (center):
- U1 Digispark in female header socket
- USB connector facing left (cable clearance)
- J1/J2 JST connectors on sides for daisy-chain

**Indicators** (bottom):
- D3, D4 LEDs visible from front
- R1-R3 resistors near their LEDs/MOSFET

### Trace Width Guidelines
- **Power (12V, GND)**: 1.5-2mm traces (handles 3A)
- **Valve switching**: 1.5mm (peak 1.6A)
- **Signal (I2C)**: 0.4-0.5mm (low current)
- **Gate/LED**: 0.3-0.4mm (mA range)

### Ground Plane
- Bottom layer: continuous ground pour
- Stitch vias around Q1 (thermal relief)
- Keep ground continuous under Digispark

---

## Assembly Variants

### Pass-Through Module (8 of 12)
**Jumper**: JP1 **CLOSED** (solder bridge)
**Populate**:
- All components EXCEPT F1 fuse holder and J4 screw terminal
- D2 Schottky: **YES** (redundant safety, recommended)

**Function**: Power flows J1 → JP1 → 12V rail → J2

---

### Injection Module (4 of 12)
**Jumper**: JP1 **OPEN** (pads not bridged)
**Populate**:
- **All components** including F1 + 3A fuse + J4 screw terminal
- D2 Schottky: **YES** (required)

**Function**: Power flows J4 → F1 → D2 → 12V rail → J2

**PSU connection**:
- 18AWG wire from PSU terminal to J4
- 5A fuse at PSU side (protects 4-module segment)

---

## Power Distribution Architecture

### System-Level Wiring (12 modules, 3 injection points)

```
PSU (12V 5A) with Wago splitter blocks:

Terminal 1 ──[5A fuse]── 18AWG ──→ Module 1 [J4 injection]
                                       ↓ JST chain
                                   Module 2 [pass-through]
                                       ↓ JST chain
                                   Module 3 [pass-through]
                                       ↓ JST chain
                                   Module 4 [pass-through]

Terminal 2 ──[5A fuse]── 18AWG ──→ Module 5 [J4 injection]
                                       ↓ JST chain
                                   Module 6-8 [pass-through]

Terminal 3 ──[5A fuse]── 18AWG ──→ Module 9 [J4 injection]
                                       ↓ JST chain
                                   Module 10-12 [pass-through]
```

### Current Budget per Segment
- 4 modules × 1A peak = 4A (slightly over JST 3A rating)
- 4 modules × 0.25A typical = 1A (well within rating)
- **Conclusion**: 3-4 modules per injection point is safe

### Cable Requirements
- **18AWG** (0.8mm²): PSU to J4 injection points
- **22AWG** (0.3mm²): JST jumper cables (pre-made)
- **JST XH cables**: 4-pin, 2.54mm pitch (AliExpress/LCSC)

---

## Firmware Notes

### I2C Addressing
- Use TinyWireS library for ATtiny85 I2C slave
- Address scheme: 0x20 + module ID (0x20-0x2B for 12 modules)
- Set address via DIP switches OR firmware flashing

### Pin Assignments
```c
// Digispark ATtiny85 pins
#define SDA_PIN      0  // P0 (I2C hardware)
#define VALVE_PIN    1  // P1 (PWM capable)
#define SCL_PIN      2  // P2 (I2C hardware)
#define LED_POWER    3  // P3 (green LED)
#define LED_VALVE    4  // P4 (yellow LED)
```

### I2C Commands
- `0x01`: Valve ON
- `0x00`: Valve OFF
- `0x10`: Get status byte
- `0x20`: Set I2C address (EEPROM)

---

## Manufacturing Files Checklist

### For JLCPCB Order
- [ ] Gerber files (CAM export from EasyEDA/KiCad)
- [ ] Drill file (PTH and NPTH)
- [ ] BOM CSV (attached: `valve_module_bom.csv`)
- [ ] Pick-and-place file (if using PCBA service)

### PCB Specifications
- Board size: 50mm × 40mm
- Layers: 2
- Thickness: 1.6mm
- Copper weight: 1oz
- Min trace/space: 0.3mm / 0.3mm
- Min drill: 0.3mm
- Surface finish: HASL or ENIG
- Solder mask: Green
- Silkscreen: White

### Quantity Recommendations
- **Prototype**: 5 PCBs (~€10 from JLCPCB)
- **Production**: 15 PCBs (12 needed + 3 spares)

---

## Cost Analysis

### Per-Module Costs
| Item | Pass-through | Injection |
|------|-------------|-----------|
| Base components | €4.10 | €4.10 |
| F1 + fuse | - | €0.50 |
| **Module total** | **€4.10** | **€4.60** |

### Full System (12 modules)
- 8× pass-through modules: 8 × €4.10 = **€32.80**
- 4× injection modules: 4 × €4.60 = **€18.40**
- PCBs (15pcs @ €10 for 5): **€30**
- JST cables (20pcs @ €0.30): **€6**
- Wire (18AWG, 22AWG): **€5**
- **Total**: **~€92** (production system)

### Prototype Budget (3 modules)
- 3× PCBs from 5pcs order: **€10**
- Components (3× €4.60): **€14**
- JST cables (5×): **€2**
- **Prototype total**: **€26**

---

## Testing and Validation

### Bench Test Checklist
- [ ] Power LED (D3) lights when 12V applied
- [ ] I2C communication verified (logic analyzer)
- [ ] Valve switches correctly via I2C command
- [ ] Valve LED (D4) lights when valve energized
- [ ] No heating on Q1 MOSFET (<60°C at 1A)
- [ ] Flyback protection (scope shows no kickback spike)
- [ ] Fused injection module protects against short

### Field Test (Museum)
- [ ] 1-2 modules installed for 1 month
- [ ] Reliability in humid environment
- [ ] No I2C communication errors
- [ ] Staff feedback on visual indicators
- [ ] Mounting and cable management validation

---

## Next Steps

### Immediate Actions
1. **Finalize schematic** in EasyEDA or KiCad
   - Import BOM from `valve_module_bom.csv`
   - Verify all footprints match library references
   - Add mounting holes (M3, 3.2mm drill)

2. **Layout PCB** (50mm × 40mm)
   - Follow placement zones from layout section
   - Route power traces first (wide, 1.5-2mm)
   - Ground pour on bottom layer
   - Silk screen labels (REF, polarity marks)

3. **Generate manufacturing files**
   - Gerber export
   - Drill files
   - Final BOM check against JLCPCB stock

4. **Order prototype**
   - 5 PCBs from JLCPCB (~€10, 5-7 days)
   - Components from LCSC (use BOM JLCPCB numbers)
   - Digispark from AliExpress (3×)

5. **Firmware development**
   - TinyWireS I2C slave code
   - Valve state machine
   - LED status indicators
   - I2C address programming

---

## Design Evolution Notes

### Lessons Learned (to be updated post-prototype)
- Component placement optimization?
- Trace width adjustments?
- Connector positioning improvements?
- Firmware quirks or timing issues?

### Future Enhancements (v1.1+)
- [ ] Add I2C address DIP switches?
- [ ] Onboard pull-ups (optional)
- [ ] TVS diode on I2C lines?
- [ ] Test points for debugging?
- [ ] Optional temperature sensor (DS18B20)?

---

## References

### Datasheets
- IRLZ44N MOSFET: https://www.infineon.com/dgdl/irlz44n.pdf
- 1N4007 Diode: Standard rectifier datasheet
- ATtiny85: https://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-2586-AVR-8-bit-Microcontroller-ATtiny25-ATtiny45-ATtiny85_Datasheet.pdf

### Design Resources
- KiCad footprint libraries
- JLCPCB parts database
- TinyWireS library: https://github.com/nadavmatalon/TinyWireS

### Project Context
- Brussels Sewer Museum water cycle controller
- Maps of Making (federated makerspace mapping)
- OpendHub Brussels

---

**Design Package Generated**: 2025-01-07  
**Tool**: electronics-shield-designer skill for Claude  
**Designer**: Nicolas @ Maps of Making

Good luck with your prototype! 🛠️
